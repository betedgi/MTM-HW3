
#ifndef WET_UTILITIES_H
#define WET_UTILITIES_H

#include <stdbool.h>
#include "list.h"
#include "map.h"

/**
 * a function which makes a list of names from a map
 * @param map a parameter from ADT map
 * @return a list of names from the map given
 */
List makeListNamesMap(Map map);
/**
 * a function which compares two string lexicographically
 * @param string1 an array of characters
 * @param string2 an array of characters
 * @return a number which indicates who is bigger 0-if equal -1-if the second
 *         and 1-if the first
 */
int stringCompar(void* string1, void* string2);
/**
 * a fuction which copies a specified string
 * @param string an array of characters
 * @return a copy of the given string
 */
void* stringCpy(void* string);
/**
 * a fuction which copies a specified constant string
 * @param string an array of characters
 * @return a copy of the given string
 */
void* stringCpyConst(const void* string);
/**
 * a function which check if the given string is qualified to be a name to a
 * series or a user
 * @param string an array of characters
 * @return true if the string is qualified and false otherwise
 */
bool stringCheckIfValid(const char* string);
/**
 * return the absolute value of a parameter from type float
 * @param num a parameter from type float
 * @return the absolute value of the parameter
 */
float absvalue(float num);
#endif //WET_UTILITIES_H
