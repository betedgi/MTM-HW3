#include "user.h"
#include "map.h"
#include "series.h"
#include "list.h"
#include "utilities.h"
#include <stdlib.h>
#include <string.h>
#include <malloc.h>

struct user_t{
    char* name;
    int age;
    List favoriteShows;
    List friends;
};


User createUser(const char* username,int age){
    if(!username || !age) return NULL;
    User user=malloc(sizeof(*user));
    if(!user){
        return NULL;
    }
    user->name=malloc((strlen(username)+1)* sizeof(char));
    if(!user->name) {
        free(user);
        return NULL;
    }
    strcpy(user->name,username);
    user->age=age;
    user->favoriteShows=listCreate(copySeries,destroySeries);
    if(!user->favoriteShows){
        free(user->name);
        free(user);
        return NULL;
    }
    user->friends=listCreate(copyUser,destroyUserList);
    if(!user->friends){
        listDestroy(user->favoriteShows);
        free(user->name);
        free(user);
        return NULL;
    }
    return user;
}

void destroyUserList(void* user){
    if(!user) return;
    User temp_user=(User)user;
    free(temp_user->name);
    free(user);
}


void destroyUser(void* user){
    if(!user) return;
    User temp_user=(User)user;
    free(temp_user->name);
    listDestroy(temp_user->favoriteShows);
    listDestroy(temp_user->friends);
    free(user);
}

void* copyUser(void* user){
    User temp_user=(User)user;
    User new_user=createUser(temp_user->name,temp_user->age);
    if(!new_user) return NULL;
    listDestroy(new_user->friends);
    listDestroy(new_user->favoriteShows);
    new_user->favoriteShows=temp_user->favoriteShows;
    new_user->friends=temp_user->friends;
    return new_user;
}

char* userGetName(User user){
    return user->name;
}

int userGetAge(User user){
    return user->age;
}

List makeListNamesListUser(List list){
    if(!list || !listGetSize(list)) return NULL;
    List list_temp=listCreate(stringCpy,free);

    LIST_FOREACH(User,iterator,list)
    {
        listInsertFirst(list_temp,iterator->name);
    }
    return list_temp;
}

List userGetFavSeries(User user){
    if(!user) return NULL;
    return user->favoriteShows;
}

List userGetFriends(User user){
    if(!user) return NULL;
    return user->friends;
}

int compareUsers(User user_1,User user_2){
    int cmpNames=stringCompar(userGetName(user_1),userGetName(user_2));
    if(cmpNames!=0) return cmpNames;
    return userGetAge(user_1)-userGetAge(user_2);
}

