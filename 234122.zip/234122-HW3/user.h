//
// Created by Ilan Etedgi on 5/16/2018.
//

#ifndef WET_USER_H
#define WET_USER_H

#include "list.h"

typedef struct user_t*  User ;

/**
 * a function which creates a new user
 * @param username the name of the user
 * @param age the age of the user
 * @return a user of user type
 */
User createUser(const char* username,int age);
/**
 * destroys all the memory the user uses and delete the user
 * @param user the user which is destroyed
 */
void destroyUser(void* user);
/**
 * a special destroy fuction which doesnt destroy the user's lists and the
 * values inside them
 * @param user the user which is destroyed
 */
void destroyUserList(void* user);
/**
 * a fuction which copies a specific user data and creates a copy of the user
 * @param user the user which needs to be copied
 * @return a copy of the user given
 */
void* copyUser(void* user);
/**
 * a fuction which receives a user and returns its age
 * @param user a parameter from type user
 * @return the given user's stored age
 */
int userGetAge(User user);
/**
 * a fuction which receives a user and returns its name
 * @param user a parameter from type user
 * @return the given user's stored name
 */
char* userGetName(User user);
/**
 * a fuction which makes a list of names from a list of users
 * @param list a list of values from type User
 * @return  a list of the names of the users from the list given
 */
List makeListNamesListUser(List list);
/**
 * a fuction which receives a user and returns its favorite series
 * @param user a parameter from type user
 * @return the given user list of favorite series
 */
List userGetFavSeries(User user);
/**
 * a fuction which receives a user and returns its friends
 * @param user a parameter from type user
 * @return the given user list of friends
 */
List userGetFriends(User user);
/**
 * a fuction which compares the data of two users
 * @param user_1 a parameter from type user
 * @param user_2 a parameter from type user
 * @return a value which indicates if they are equal by value or has diffrences
 *         between them
 */
int compareUsers(User user_1,User user_2);
#endif //WET_USER_H
