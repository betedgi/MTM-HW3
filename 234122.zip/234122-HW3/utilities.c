
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "list.h"
#include "map.h"

void* stringCpy(void* string){
    char* new_string=malloc(sizeof(char)*(strlen((char*)string)+1));
    if(!new_string) return NULL;
    strcpy(new_string,string);
    return new_string;
}

void* stringCpyConst(const void* string){
    char* new_string=malloc(sizeof(char)*(strlen((char*)string)+1));
    if(!new_string) return NULL;
    strcpy(new_string,string);
    return new_string;
}

int stringCompar(void* string1,void* string2){
    char* temp_string1=(char*)string1;
    char* temp_string2=(char*)string2;
    return strcmp(temp_string1,temp_string2);
}


bool stringCheckIfValid(const char* string){
    int index=0;
    while(index<strlen(string)){
        if((*(string+index)<='Z' && *(string+index)>='A')
            || (*(string+index)<='z' && *(string+index)>='a')||
                (*(string+index)<='9' && (*(string+index)>='0'))){
            index++;
            continue;
        }

        return false;
    }
    return true;
}

List makeListNamesMap(Map map){
    if(!map || !mapGetSize(map)) return NULL;
    List list=listCreate(stringCpy,free);
    MAP_FOREACH(char*,iterator,map){
        listInsertFirst(list,iterator);
    }
    return list;
}

float absvalue(float num){
    return (num<0)*(-num)+(num>=0)*num;
}
