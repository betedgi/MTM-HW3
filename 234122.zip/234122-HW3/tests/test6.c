#include "../mtmflix.h"
#include "test_utilities.h"
#include <stdio.h>

bool mtmFlixSeriesLeaveTest(){
	MtmFlix mf = mtmFlixCreate();
	ASSERT_TEST(mf);

	int ages[2] = {10, 30};

	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddUser(mf, "Saifun", 19));
	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddUser(mf, "Niko", 36));

	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddSeries(mf, "Matam", 10, ROMANCE, ages, 10));
	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddSeries(mf, "Atam", 20, DRAMA, ages, 10));

	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixSeriesJoin(mf, "Saifun", "Matam"));
	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixSeriesJoin(mf, "Saifun", "Atam"));

	ASSERT_TEST(MTMFLIX_NULL_ARGUMENT == mtmFlixSeriesLeave(NULL, "Saifun", "Matam"));
	ASSERT_TEST(MTMFLIX_NULL_ARGUMENT == mtmFlixSeriesLeave(mf, NULL, "Matam"));
	ASSERT_TEST(MTMFLIX_NULL_ARGUMENT == mtmFlixSeriesLeave(mf, "Saifun", NULL));

	ASSERT_TEST(MTMFLIX_USER_DOES_NOT_EXIST == mtmFlixSeriesLeave(mf, "Denis", "Matam"));
	ASSERT_TEST(MTMFLIX_USER_DOES_NOT_EXIST == mtmFlixSeriesLeave(mf, "Denis", "Matan"));
	ASSERT_TEST(MTMFLIX_SERIES_DOES_NOT_EXIST == mtmFlixSeriesLeave(mf, "Saifun", "Matan"));

	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixSeriesLeave(mf, "Saifun", "Matam"));

	mtmFlixDestroy(mf);
	return true;
}

int main() {
	RUN_TEST(mtmFlixSeriesLeaveTest);
	return 0;
}