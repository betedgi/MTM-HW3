#include "../mtmflix.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "../mtm_ex3.h"

#define AgeArraysSize 16
#define SeriesSize 18
#define UsersSize 21 

//const char* series[] = {"s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "s8", "s9", "s10", "s11", "s12", "s13", "s14", "s15", "s16", "s17"};
//const char* users[] = {"u0", "u1", "u2", "u3", "u4", "u5", "u6", "u7", "u8", "u9", "u10", "u11", "u12", "u13", "u14", "u15", "u16", "u17", "u18", "u19", "u20"};
int agesUnder[2] = {1, 8};
int agesOver[2] = {50, 235};
int agesTeen[2] = {11, 18};
int agesAdult[2] = {20, 60};
int agesGrand[2] = {60, MTM_MAX_AGE};
int agesAll[2] = {MTM_MIN_AGE, MTM_MAX_AGE};
int* agesArraysPointers[] = {agesUnder, agesOver, agesOver, agesOver, agesTeen, agesAdult, agesGrand, agesAll, agesAdult, agesGrand, agesAll, agesAdult, agesGrand, agesAll, agesAll, agesAll};
char* agesArrays[] = {"agesUnder", "agesOver", "agesOver", "agesOver", "agesTeen", "agesAdult", "agesGrand", "agesAll", "agesAdult", "agesGrand", "agesAll", "agesAdult", "agesGrand", "agesAll", "agesAll", "agesAll"};
//Genre genres[] = {SCIENCE_FICTION, DRAMA, COMEDY, CRIME, MYSTERY, DOCUMENTARY, ROMANCE, HORROR};
const char* results[] = {"MTMFLIX_SUCCESS", "MTMFLIX_OUT_OF_MEMORY", "MTMFLIX_CANNOT_OPEN_FILE", \
"MTMFLIX_NULL_ARGUMENT","MTMFLIX_ILLEGAL_USERNAME","MTMFLIX_USERNAME_ALREADY_USED","MTMFLIX_ILLEGAL_AGE", \
"MTMFLIX_USER_DOES_NOT_EXIST","MTMFLIX_ILLEGAL_SERIES_NAME","MTMFLIX_SERIES_ALREADY_EXISTS", \
"MTMFLIX_ILLEGAL_EPISODES_NUM","MTMFLIX_ILLEGAL_EPISODES_DURATION","MTMFLIX_SERIES_DOES_NOT_EXIST", \
"MTMFLIX_NO_SERIES","MTMFLIX_ILLEGAL_NUMBER","MTMFLIX_NO_USERS","MTMFLIX_USER_NOT_IN_THE_RIGHT_AGE"};
