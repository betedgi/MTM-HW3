#include "../mtmflix.h"
#include "test_utilities.h"
#include <stdio.h>

bool mtmFlixReportSeriesTest(){
	MtmFlix mf = mtmFlixCreate();
	ASSERT_TEST(mf);

	int ages[2] = {10, 30};

	ASSERT_TEST(MTMFLIX_NO_SERIES == mtmFlixReportSeries(mf, 0, stdout));

	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddSeries(mf, "Booy", 10, ROMANCE, ages, 10));

	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddSeries(mf, "Boow", 20, DRAMA, ages, 10));
	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddSeries(mf, "Boo", 20, DRAMA, ages, 10));

	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddSeries(mf, "Booq", 20, COMEDY, ages, 10));
	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddSeries(mf, "Booe", 20, COMEDY, ages, 10));
	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddSeries(mf, "Book", 20, COMEDY, ages, 10));

	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddSeries(mf, "Boop", 20, MYSTERY, ages, 10));

	ASSERT_TEST(MTMFLIX_NULL_ARGUMENT == mtmFlixReportSeries(NULL, 0, stdout));
	ASSERT_TEST(MTMFLIX_NULL_ARGUMENT == mtmFlixReportSeries(mf, 0, NULL));

	FILE* pFile = fopen ("diff/out9", "w");

	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixReportSeries(mf, 0, pFile));
	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixReportSeries(mf, 1, pFile));
	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixReportSeries(mf, 4, pFile));

	fclose(pFile);

	mtmFlixDestroy(mf);
	return true;
}

int main() {
	RUN_TEST(mtmFlixReportSeriesTest);
	return 0;
}