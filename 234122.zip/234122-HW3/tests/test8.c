#include "../mtmflix.h"
#include "test_utilities.h"
#include <stdio.h>

bool mtmFlixRemoveFriendTest(){
	MtmFlix mf = mtmFlixCreate();
	ASSERT_TEST(mf);

	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddUser(mf, "Saifun", 19));
	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddUser(mf, "Niko", 36));
	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddUser(mf, "Denis", 28));

	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddFriend(mf, "Saifun", "Niko"));
	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddFriend(mf, "Saifun", "Denis"));
	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddFriend(mf, "Niko", "Saifun"));
	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddFriend(mf, "Niko", "Denis"));
	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddFriend(mf, "Denis", "Niko"));
	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddFriend(mf, "Denis", "Saifun"));

	ASSERT_TEST(MTMFLIX_NULL_ARGUMENT == mtmFlixRemoveFriend(NULL, "Niko", "Saifun"));
	ASSERT_TEST(MTMFLIX_NULL_ARGUMENT == mtmFlixRemoveFriend(mf, NULL, "Saifun"));
	ASSERT_TEST(MTMFLIX_NULL_ARGUMENT == mtmFlixRemoveFriend(mf, "Niko", NULL));

	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixRemoveFriend(mf, "Niko", "Denis"));
	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixRemoveFriend(mf, "Denis", "Niko"));
	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixRemoveFriend(mf, "Denis", "Saifun"));

	mtmFlixDestroy(mf);
	return true;
}

int main() {
	RUN_TEST(mtmFlixRemoveFriendTest);
	return 0;
}