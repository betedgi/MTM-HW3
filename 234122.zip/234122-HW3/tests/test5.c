#include "../mtmflix.h"
#include "test_utilities.h"
#include <stdio.h>

bool mtmFlixSeriesJoinTest(){
	MtmFlix mf = mtmFlixCreate();
	ASSERT_TEST(mf);

	int ages[2] = {10, 30};
	int agesMin[2] = {MTM_MIN_AGE, MTM_MIN_AGE};

	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddUser(mf, "Saifun", 20));
	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddUser(mf, "Niko", 36));
	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddUser(mf, "Arnav", 7));
	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddUser(mf, "minmax", MTM_MIN_AGE));
	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddUser(mf, "almostMin", MTM_MIN_AGE + 1));

	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddSeries(mf, "Matam", 10, ROMANCE, ages, 10));
	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddSeries(mf, "Atam", 20, DRAMA, ages, 10));
	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddSeries(mf, "SomethingStupid", 20, COMEDY, agesMin, 10));

	ASSERT_TEST(MTMFLIX_NULL_ARGUMENT == mtmFlixSeriesJoin(NULL, "Niko", "Atam"));
	ASSERT_TEST(MTMFLIX_NULL_ARGUMENT == mtmFlixSeriesJoin(mf, NULL, "Atam"));
	ASSERT_TEST(MTMFLIX_NULL_ARGUMENT == mtmFlixSeriesJoin(mf, "Niko", NULL));

	ASSERT_TEST(MTMFLIX_USER_DOES_NOT_EXIST == mtmFlixSeriesJoin(mf, "Denis", "Atam"));
	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddUser(mf, "Denis", 28));
	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixSeriesJoin(mf, "Denis", "Atam"));
	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixRemoveUser(mf, "Denis"));
	ASSERT_TEST(MTMFLIX_USER_DOES_NOT_EXIST == mtmFlixSeriesJoin(mf, "Denis", "Atam"));

	ASSERT_TEST(MTMFLIX_SERIES_DOES_NOT_EXIST == mtmFlixSeriesJoin(mf, "Saifun", "Natam"));
	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixSeriesJoin(mf, "Saifun", "Matam"));
	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixSeriesJoin(mf, "Saifun", "Matam"));

	ASSERT_TEST(MTMFLIX_USER_NOT_IN_THE_RIGHT_AGE == mtmFlixSeriesJoin(mf, "Niko", "Atam"));
	ASSERT_TEST(MTMFLIX_USER_NOT_IN_THE_RIGHT_AGE == mtmFlixSeriesJoin(mf, "Arnav", "Matam"));
	
	ASSERT_TEST(MTMFLIX_USER_NOT_IN_THE_RIGHT_AGE == mtmFlixSeriesJoin(mf, "almostMin", "SomethingStupid"));
	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixSeriesJoin(mf, "minmax", "SomethingStupid"));
	
	mtmFlixDestroy(mf);

	return true;
}

int main() {
	RUN_TEST(mtmFlixSeriesJoinTest);
	return 0;
}