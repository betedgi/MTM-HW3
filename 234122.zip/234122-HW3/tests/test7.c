#include "../mtmflix.h"
#include "test_utilities.h"
#include <stdio.h>

bool mtmFlixAddFriendTest(){
	MtmFlix mf = mtmFlixCreate();
	ASSERT_TEST(mf);

	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddUser(mf, "Saifun", 19));
	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddUser(mf, "Niko", 36));
	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddUser(mf, "Denis", 28));

	ASSERT_TEST(MTMFLIX_NULL_ARGUMENT == mtmFlixAddFriend(NULL, "Niko", "Saifun"));
	ASSERT_TEST(MTMFLIX_NULL_ARGUMENT == mtmFlixAddFriend(mf, NULL, "Saifun"));
	ASSERT_TEST(MTMFLIX_NULL_ARGUMENT == mtmFlixAddFriend(mf, "Niko", NULL));

	ASSERT_TEST(MTMFLIX_USER_DOES_NOT_EXIST == mtmFlixAddFriend(mf, "Nako", "Saifun"));
	ASSERT_TEST(MTMFLIX_USER_DOES_NOT_EXIST == mtmFlixAddFriend(mf, "Niko", "Saifan"));
	ASSERT_TEST(MTMFLIX_USER_DOES_NOT_EXIST == mtmFlixAddFriend(mf, "Nako", "Saifan"));

	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddFriend(mf, "Saifun", "Niko"));
	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddFriend(mf, "Saifun", "Niko"));
	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddFriend(mf, "Saifun", "Denis"));
	ASSERT_TEST(MTMFLIX_SUCCESS == mtmFlixAddFriend(mf, "Niko", "Saifun"));

	mtmFlixDestroy(mf);
	return true;
}

int main() {
	RUN_TEST(mtmFlixAddFriendTest);
	return 0;
}